import os
import sys
import time
#sys.path.append('/home/heday/Projects/CUDARibosomeSimulator/build')
#import ribosomesimulatorCUDA
from ribosomesimulator import ribosomesimulator
import csv
import pandas as pd
import numpy as np
from joblib import Parallel, delayed
import random

concentration_files_dict = {}

def get_df(concentrations_file_name):
    if concentrations_file_name.endswith(".csv") and (not os.path.isfile("decoding_times/"+concentrations_file_name)): #  or concentrations_file_name.endswith("base_configuration.csv")):
        df = pd.read_csv("concs/"+concentrations_file_name)
        return (concentrations_file_name, df)
    return (None, None)

parallel = Parallel(n_jobs=-1, verbose=10)

results = []
concs = os.listdir("concs/")
decoding_times = os.listdir("decoding_times/")

#list(set(concs) - set(decoding_times))

results = parallel(delayed(get_df)(concentrations_file_name) for concentrations_file_name in list(set(concs) - set(decoding_times)))

print("read concentrations files")
# This shuffling is not in-place
random.shuffle(results)
##results = sorted(results, key=len)
concentration_files_dict = {k:df for k, df in results if k is not None}
print("files list shuffled")

codons_to_simulate = list(concentration_files_dict['base_configuration.csv'].codon.values)
# remove stop codons:
for codon in ["UAA", "UAG", "UGA"]:
    codons_to_simulate.remove(codon)

def check_if_all_codons_can_decode(df, file_name):
    dataframe = df.set_index("codon")
    if np.any((df[['WCcognate.conc', 'wobblecognate.conc']][~df.codon.isin(["UAA", "UAG", "UGA"])] == 0.0).all(axis=1)):
        # can't decode all codons
        print("Can't decode all codons in concentration: " +file_name+" Removing file.")
        os.remove("concs/"+file_name)
        return

# parallel = Parallel(n_jobs=-1, verbose=10)
# results = parallel(delayed(check_if_all_codons_can_decode)(df, file_name) for file_name, df in concentration_files_dict.items())



def simulate_configuration(df, file_name):
    if os.path.isfile("decoding_times/"+file_name):
        # file exists. simulation was  previously completed. skip
        return
    dataframe = df.set_index("codon")
    if np.any((df[['WCcognate.conc', 'wobblecognate.conc']][~df.codon.isin(["UAA", "UAG", "UGA"])] == 0.0).all(axis=1)):
        # can't decode all codons
        print("Can't decode all codons in concentration: " +file_name+" Skipping.")
        return

    sim = ribosomesimulator()
    sim.loadConcentrationsFromString(df.to_csv(index=False))
    result = {}
    for codon in codons_to_simulate:
        sim.setCodonForSimulation(codon)
        prop_dict = sim.getPropensities()
        result[codon] = sim.run_repeatedly_get_average_time(300000)
    result_df = pd.DataFrame(result.items(), columns=['codon', 'average_decoding_time'])
    result_df.to_csv("decoding_times/" + file_name, index=False, quoting=csv.QUOTE_NONNUMERIC)
    return

parallel = Parallel(n_jobs=-1, verbose=10)
#results = parallel(delayed(simulate_configuration_GPU)(df, file_name) for file_name, df in concentration_files_dict.items())
results = parallel(delayed(simulate_configuration)(df, file_name) for file_name, df in concentration_files_dict.items())


# for file_name, df in list(concentration_files_dict.items()):
#     print("processing: "+file_name)
#     result = simulate_configuration_GPU(df, file_name)
#     print("done")
