import os
from concentrations import concentrations_generator
import pandas as pd
import csv
from joblib import Parallel, delayed

def generate_concentration(file, tRNAs, codons):
    if os.path.isfile("concs/"+file.split('.')[0]+".csv"):
        # file exists. skip
        return
    concentrations_df = concentrations_generator.make_concentrations(concentrations_generator.make_matrix(tRNAs, codons, verbose=False, settings_file_name="pairings/"+file), tRNAs, codons)
    concentrations_df["three.letter"] = codons["three.letter"]
    concentrations_df = concentrations_df.reindex(columns=['codon', "three.letter", 'WCcognate.conc', 'wobblecognate.conc', 'nearcognate.conc'])
    concentrations_df.to_csv("concs/"+file.split('.')[0]+".csv", index=False, quoting=csv.QUOTE_NONNUMERIC)
    return

tRNAs = pd.read_csv('/home/fd85/Projects/R_concentrations/data/tRNAs.csv')
codons = pd.read_csv('/home/fd85/Projects/R_concentrations/data/codons.csv')
if "decoding.time" in codons.columns:
    del codons["decoding.time"]
parallel = Parallel(n_jobs=-1, verbose=10)
results = parallel(delayed(generate_concentration)(file_name, tRNAs, codons) for file_name in os.listdir("pairings/"))



