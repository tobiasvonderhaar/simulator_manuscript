import os
import json
import copy
import numpy as np
from sklearn.model_selection import LeavePOut

with open("/home/fd85/Projects/Gillespie_Cpp/concentrations/default_basepairing.json") as f:
    base_configuration = json.load(f)

# put new configurations
base_configuration['Pairing Rules']['Near-Cognate']['base-level'] = [["Wo","WC","X"], ["X","WC","Wo"]]

total_anticodons = np.sum([len(b) for _,b in base_configuration['Wobble'].items()])

X = np.ones(total_anticodons)
indexes_to_remove = []
for i in range(1, 4):
    lpo = LeavePOut(p=i)
    for _, test in lpo.split(X):
        indexes_to_remove.append(test)

def decode_indexes_to_remove(idxs_to_remove, base_configuration=base_configuration):
    # upper_indexes = np.cumsum([len(b) for _,b in base_configuration['Wobble'].items()])-1
    lower_indexes = np.hstack([[0], np.cumsum([len(b) for _,b in base_configuration['Wobble'].items()])[:-1]])
    codons_list = list(base_configuration['Wobble'].keys())
    result = {}
    for idx in idxs_to_remove:
        # locate the codon we are talking about
        codon_index = np.argwhere(idx>=lower_indexes)[-1][0]
        anticodon_index = idx - lower_indexes[codon_index]
        codon = codons_list[codon_index]
        anticodon = base_configuration['Wobble'][codon][anticodon_index]
        if codon in result.keys():
            if anticodon not in result[codon]:
                result[codon].append(anticodon)
        else:
            result[codon] = [anticodon]
    return result

all_configurations =  [copy.deepcopy(base_configuration) for i in range(len(indexes_to_remove))]
file_names = []
for current_conf, idx_tuple_to_remove in zip(all_configurations, indexes_to_remove):
    dict_to_remove = decode_indexes_to_remove(idx_tuple_to_remove, base_configuration=current_conf)
    for codon, list_anticodons in dict_to_remove.items():
        for anticodon in list_anticodons:
            current_conf['Wobble'][codon].remove(anticodon)
    # build file name:
    fn = ''
    for codon, list_anticodons in dict_to_remove.items():
        for anticodon in list_anticodons:
            fn += "Wo_"+codon+"_"+anticodon+ " "
    file_names.append(fn[:-1]+".json")

import collections
print([item for item, count in collections.Counter(file_names).items() if count > 1])

for file_name, configuration in zip(file_names, all_configurations):
    print(file_name)
    if os.path.isfile("pairings/"+file_name.split('.')[0]+".json"):
        print("true")
        break
    break


for file_name, configuration in zip(file_names, all_configurations):
    if os.path.isfile("pairings/"+file_name.split('.')[0]+".json"):
        # file exists. skip.
        continue
    else:
        # file doesn't exists. create it.
        with open("pairings/"+file_name, "w") as outfile:
            outfile.write(json.dumps(configuration, indent=4))

with open("pairings/base_configuration.json", "w") as outfile:
        outfile.write(json.dumps(base_configuration, indent=4))

